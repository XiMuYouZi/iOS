//
//  fetchPhotos.h
//  Tecent-cartoon
//
//  Created by Mia on 16/1/18.
//  Copyright © 2016年 Mia. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "fetchHomePageJsonData.h"

@interface fetchPhotos :fetchHomePageJsonData

-(NSArray *)getBannerPhotoURL;
+ (instancetype)sharedInstance;

@end
