//
//  bannerCellModel.h
//  Tecent-cartoon
//
//  Created by Mia on 16/1/18.
//  Copyright © 2016年 Mia. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface bannerCellModel : NSObject
@property(nonatomic,strong)UIImage *Image;
@property(nonatomic,strong)NSString *title;

@end
