//
//  main.m
//  Tecent-cartoon
//
//  Created by Mia on 16/1/16.
//  Copyright © 2016年 Mia. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
