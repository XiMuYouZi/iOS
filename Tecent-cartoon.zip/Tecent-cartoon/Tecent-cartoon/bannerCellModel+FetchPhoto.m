//
//  bannerCellModel+FetchPhoto.m
//  Tecent-cartoon
//
//  Created by Mia on 16/1/18.
//  Copyright © 2016年 Mia. All rights reserved.
//

#import "bannerCellModel+FetchPhoto.h"
#import "fetchPhotos.h"


@implementation bannerCellModel (FetchPhoto)


//暴露一个block接口给homepagecontroller,把banner的photo传递给它
+(void)fetchBannerPhotos:(FetchPhotoBlock)completionBlock
{
    
    NSMutableDictionary *allJsonData=[[NSMutableDictionary alloc]init];

//    获取所有的首页的json数据
    allJsonData=[[[fetchPhotos sharedInstance]getBannerPhotoURL]copy];
    
//    获取banner_url
    
    
    
//    使用block属性传递数据到HomePageController，传递的数据就是mutableArray
    if (completionBlock) {
        completionBlock([allJsonData copy]);

    }
    
}


@end
